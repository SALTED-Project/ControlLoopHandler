"""
controlloophandlerhandler.

Control Loop handler for control loop mechanism within SALTED.'
"""

__version__ = "0.1.0"
__author__ = ''
