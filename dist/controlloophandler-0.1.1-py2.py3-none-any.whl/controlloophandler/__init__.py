"""
controlloophandler.

Control Loop handler for control loop mechanism within SALTED.'
"""

__version__ = "0.1.1"
__author__ = 'Víctor González'
